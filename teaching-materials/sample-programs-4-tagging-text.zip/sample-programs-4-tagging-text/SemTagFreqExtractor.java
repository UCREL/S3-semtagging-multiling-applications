
import ac.uk.lancs.ucrel.semtaggers.web.clients.SemanticTaggerClient;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import semtagger.welsh.webservice.client.WelshTaggerClient;

/**
 * This is a sample program for extracting frequencies of semantic from text.
 * This program is to be compiled together with a web service client library
 * files contained in the folder "./lib/" in the class path.
 *
 * @author Scott Piao (s.piao@lancaster.ac.uk). Last updated 21 June 2917.
 */
public class SemTagFreqExtractor {

    public static void main(String[] args) {

        //Initiate taggers
        SemanticTaggerClient semanticTagger = new SemanticTaggerClient();
        WelshTaggerClient welshTagger = new WelshTaggerClient();

        //Set the maximum size of documents allowed.
        int maxTextSize = 10000;

        //instantiate OpenSaveFile class used to open and save file.
        OpenSaveFile fileOpenSave = new OpenSaveFile();
        String encodingName = "UTF8";

        //Prepare file paths text from files
        String filePath1 = "files-4-test/english-sample-1.txt";
        String filePath2 = "files-4-test/english-sample-2.txt";

        //Get text from the files using file namaging class
        String text1 = fileOpenSave.getStringFromFile(filePath1, encodingName);
        String text2 = fileOpenSave.getStringFromFile(filePath1, encodingName);

        //Check the size of files.
        String[] words1 = text1.split(" ");
        String[] words2 = text2.split(" ");
        if (words1.length > maxTextSize || words2.length > maxTextSize) {
            System.out.println("File size is too big");
            System.exit(0);
        }

        //Tag texts by calling the semantic tagger and merge the tagged texts together. 
        String taggedText = semanticTagger.tagEngText(text1);
        taggedText += semanticTagger.tagEngText(text2);

        //Below we extract frequencies of semantic tags
        
        //Prepare a Map object to keep the frequencies
        Map<String, Integer> semTagFrequencies = new TreeMap<String, Integer>();

        //Read text line by line.
        StringTokenizer textLines = new StringTokenizer(taggedText, "\n");
        while (textLines.hasMoreTokens()) {
            String line = textLines.nextToken();

            if (line.equals("")) {
                continue;
            }

            //Break a line into columns
            String[] lineColumns = line.split("\t");

            //If a line has fewer than five columns, skip
            if (lineColumns.length < 5) {
                continue;
            }

            //Here only consider USAS semantic tag
            String usasSemTagList = lineColumns[3];

            //Break down tag list into individual tags
            String[] usasTags = usasSemTagList.split("[ /]");

            for (int i = 0; i < usasTags.length; i++) {
                String tag = usasTags[i];

                //Filter out closed class words e.g. function words and names
                if (tag.startsWith("Z") || tag.startsWith("PUNC") || tag.startsWith("a")) {
                    continue;
                }

                //Check whether or not the tag is already in the frequency list. If yes, increase frequency by one; if not give frequency of one. 
                Integer freq = semTagFrequencies.get(tag);

                if (freq != null) {
                    semTagFrequencies.put(tag, ++freq);
                } else {
                    semTagFrequencies.put(tag, 1);
                }

            }

        }

        //Print out frequency list and append it to a StringBuffer
        Set<String> keys = semTagFrequencies.keySet();
        
        StringBuilder freqList = new StringBuilder();
        for (String key : keys) {
            Integer freq = semTagFrequencies.get(key);
            System.out.println(key + "\t" + freq);
            freqList.append(key + "\t" + freq + "\n");
        }

        //Save the frequency list into a spreadsheet file
        String outFileName = "files-4-test/sem-tags-frequencies.csv";
        fileOpenSave.saveTextToFile(freqList.toString(), outFileName, encodingName);
        
        //Now you can open the file "sem-tags-frequencies.csv" in spreadsheet.
        //You can alsoo generate several frequency files from different documents and do comparison etc. 

    }
}

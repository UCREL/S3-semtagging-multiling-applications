import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;

/**
This class contains various methods for opening file and saving text into file.
@author Scott Piao (s.piao@lancaster.ac.uk)
 */
public class OpenSaveFile {

    /**Saves an input text into a specified file.
    @param text A String to be saved.
    @param f A file path to save the input String.*/
    public void saveTextToFile(String text, File f) {
        try {
            Writer outf;
            outf = new OutputStreamWriter(new FileOutputStream(f));
            outf.write(text);
            outf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**Saves an input text into a specified file.
    @param text A String to be saved.
    @param fname A file name in String including path.*/
    public void saveTextToFile(String text, String fname) {
        File file = new File(fname);
        if (file == null || file.getName().equals("")) {
            return;
        } else {
            try {
                Writer outf;
                outf = new OutputStreamWriter(new FileOutputStream(file));

                outf.write(text);
                outf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**Saves an input text into a specified file with specified encoding.
    @param text A String to be saved.
    @param fname A file name in String including path.
    @param encode An encoding name supported by Java from version 1.3.*/
    public void saveTextToFile(String text, String fname, String encode) {
        File file = new File(fname);
        if (file == null || file.getName().equals("")) {
            return;
        } else {
            try {
                Writer outf;
                outf = new OutputStreamWriter(new FileOutputStream(file), encode);

                outf.write(text);
                outf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**Saves an input text into a specified file.
    @param text A String to be saved.
    @param f A File to save the input String.
    @param encode An encoding name supported by Java.*/
    public void saveTextToFile(String text, File f, String encode) {

        try {
            Writer outf;
            outf = new OutputStreamWriter(new FileOutputStream(f), encode);
            outf.write(text);
            outf.close();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    /**Saves an object into a file.
    @param object A Java Object to be saved.
    @param f A file in which the input object is saved.
     */
    public void saveObjectToFile(Object object, File f) {

        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f));
            out.writeObject(object);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

    /**Saves an object into a file.
    @param object A Java Object to be saved.
    @param fpath String file path in which the input object is saved.
     */
    public void saveObjectToFile(Object object, String fpath) {

        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fpath));
            out.writeObject(object);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

    /**Returns the contents of an output file in String.
    @param f An input file.
    @return A String containing the contents of the input file.*/
    public String getStringFromFile(File f) {
        StringBuilder str = new StringBuilder();
        try {
            InputStreamReader is = new InputStreamReader(new FileInputStream(f));
            Reader ins = new BufferedReader(is);
            int ch;
            while ((ch = ins.read()) > -1) {
                str.append((char) ch);
            }
            ins.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return str.toString();
    }

    /**Returns the contents of an output file in String.
    @param fname A file name in String.
    @return A String containing the contents of the input file.*/
    public String getStringFromFile(String fname) {

        StringBuilder str = new StringBuilder();
        try {
            File f = new File(fname);
            InputStreamReader is = new InputStreamReader(new FileInputStream(f));
            Reader ins = new BufferedReader(is);
            int ch;
            while ((ch = ins.read()) > -1) {
                str.append((char) ch);
            }
            ins.close();
        } catch (IOException e) {

            e.printStackTrace();
            return null;
        }
        return str.toString();
    }

    /**Reads the specified encoding and returns the contents of an input file in String .
    @param f An input File.
    @param encode Name of the encoding in which the output file is written.
    @return A String containing the contents of the input file.*/
    public String getStringFromFile(File f, String encode) {

        StringBuilder str = new StringBuilder();
        try {
            InputStreamReader is = new InputStreamReader(new FileInputStream(f), encode);
            Reader ins = new BufferedReader(is);
            int ch;
            while ((ch = ins.read()) > -1) {
                str.append((char) ch);
            }
            ins.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return str.toString();
    }

    /**Reads the specified encoding and returns the contents of an output file in String .
    @param f An input File.
    @param encode Name of the encoding in which the output file is written.
    @return A String containing the contents of the input file.*/
    public String getStringFromFile(String f, String encode) {

        StringBuilder str = new StringBuilder();
        try {
            InputStreamReader is = new InputStreamReader(new FileInputStream(f), encode);
            Reader ins = new BufferedReader(is);
            int ch;
            while ((ch = ins.read()) > -1) {
                str.append((char) ch);
            }
            ins.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return str.toString();
    }

    /**Reads an array of output files and returns the contents in String in extended ASCII.
    @param f A File array to be read.
    @return A String containing the contents of the input file.*/
    public String getStringFromFiles(File[] fs) {
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < fs.length; i++) {
            str.append(getStringFromFile(fs[i]) + "\n");
        }
        return str.toString();
    }

    /**Reads the specified encoding and returns the contents of an array of output files in String .
    @param f A File array to be read.
    @param encode Name of the encoding in which the output file is written.
    @return A String containing the contents of the input file.*/
    public String getStringFromFiles(File[] fs, String encode) {

        StringBuilder str = new StringBuilder();
        for (int i = 0; i < fs.length; i++) {
            str.append(getStringFromFile(fs[i], encode) + "\n");
        }
        return str.toString();
    }

    /**Merges and returns the contents of the files under the directory specified by the passing File.
    @param dir A File object specifying a directory.
    @return A String containing merged contents of all the files under the specified directory.*/
    public String getStringOfFilesInDirectory(File dir) {

        String fList[] = dir.list();
        if (fList.length == 0) {
            return null;
        }
        Arrays.sort(fList);
        StringBuilder txts = new StringBuilder();
        int file_number = 0;
        for (int k = 0; k < fList.length; k++) {
            File file = new File(dir, fList[k]);
            if (file.isFile()) {
                file_number++;
                txts.append(getStringFromFile(file) + "\n");
            }
        }

        if (file_number > 0) {
            return txts.toString();
        } else {
            return null;
        }
    }

    /**Opens the input file and put lines into a List and return the List.
    @param f An input File
    @return A List containing the lines of the input file.*/
    public List<String> getListOfLinesFromFile(File f) {

        String str = getStringFromFile(f);

        if (str == null) {
            return null;
        }


        StringTokenizer st = new StringTokenizer(str, "\n\r");
        List<String> list = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            String next_tok = st.nextToken();
            if (next_tok.trim().equals("")) {
                continue;
            }
            list.add(next_tok);
        }
        return list;
    }

    /**Reads text file included in a Jar file.
     * @param filePath Directory path of a file.
     * @param encode Name of the encoding in which the output file is written.
     * @return String contents of the file in String.
     */
    public String getTextFromJar(String filePath, String encode) {
        String line;
        try {
            InputStream is = getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, encode));

            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**Opens the input file and put lines into a List and return the List.
    @param fname A file name in String including path
    @return A List containing the lines of the input file.*/
    public List<String> getListOfLinesFromFile(String fname) {

        String str = getStringFromFile(fname);

        if (str == null) {
            return null;
        }

        StringTokenizer st = new StringTokenizer(str, "\n\r");
        List<String> list = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            String next_tok = st.nextToken().trim();
            if (next_tok.equals("")) {
                continue;
            }
            list.add(next_tok);
        }
        return list;
    }

    /**Opens the input file and put lines into a List and return the List.
    @param fname A file name in String including path
    @param encode Encoding name.
    @return A List containing the lines of the input file.*/
    public List<String> getListOfLinesFromFile(String fname, String encode) {

        String str = getStringFromFile(fname, encode);
        if (str == null) {
            return null;
        }

        StringTokenizer st = new StringTokenizer(str, "\n\r");
        List<String> list = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            String next_tok = st.nextToken().trim();
            if (next_tok.equals("")) {
                continue;
            }
            list.add(next_tok);
        }
        return list;
    }

    /**Opens the a file from JAR and put lines into a List and return the List.
    @param fname A file name in String including path
    @param encode Encoding name.
    @return A List containing the lines of the input file.*/
    public List<String> getListOfLinesFromJar(String fname, String encode) {

        String str = getTextFromJar(fname, encode);

        if (str == null) {
            return null;
        }

        StringTokenizer st = new StringTokenizer(str, "\n\r");
        List<String> list = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            String next_tok = st.nextToken();
            if (next_tok.trim().equals("")) {
                continue;
            }
            list.add(next_tok);
        }
        return list;
    }

    /**Extracts an object from the input file.
    @param f A File to be read.
    @return An Object extracted from the input file.*/
    public Object getObjectFromFile(File f) {

        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(f));
            Object ojt = (Object) in.readObject();
            in.close();
            return ojt;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**Extracts an object from the input file.
    @param fpath A file path in String.
    @return An Object extracted from the input file.*/
    public Object getObjectFromFile(String fpath) {

        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(fpath));
            Object ojt = (Object) in.readObject();
            in.close();
            return ojt;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}



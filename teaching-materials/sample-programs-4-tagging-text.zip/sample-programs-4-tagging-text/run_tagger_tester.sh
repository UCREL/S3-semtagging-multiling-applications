#!/bin/sh

java -cp .:lib/* UcrelMultilingSemTaggerTester


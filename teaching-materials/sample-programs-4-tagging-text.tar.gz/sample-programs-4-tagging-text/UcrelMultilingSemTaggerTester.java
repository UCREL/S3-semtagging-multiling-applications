
import ac.uk.lancs.ucrel.semtaggers.web.clients.SemanticTaggerClient;
import semtagger.welsh.webservice.client.WelshTaggerClient;

/**
 * This is a sample program for accessing USAS semantic tagger web service
 * resided in Lancaster University. This program is to be compiled together with
 * a web service client library files contained in the folder "./lib/" in the
 * class path.
 *
 * @author Scott Piao (s.piao@lancaster.ac.uk). Last updated 21 June 2917.
 */
public class UcrelMultilingSemTaggerTester {

    public static void main(String[] args) {

        //Initiate taggers
        SemanticTaggerClient semanticTagger = new SemanticTaggerClient();
        WelshTaggerClient welshTagger = new WelshTaggerClient();

        //Limit the size of input text within 10000 words/tokens.
        int maxTextSize = 10000;

        String chineseText = "替换我们工厂的部分落后设备。";
        String dutchText = "Wij vinden het belangrijk dat u weet wat te doen in het land waar u heen reist. Daarom staat het routeboek ook vol handige informatie als nuttige adressen, brandstof, verkeersvoorschriften, valuta en grensformaliteiten. Zo bent u goed voorbereid op het land en de regio’s waar u komt tijdens uw kampeerreis.";
        String englishText = "This is a test only.";
        String frenchText = "L'an prochain, cette classe n'existera plus.";
        String italianText = "Non si al mondo capisce se per una malintesa carità di Italiano patria o per un ormai inspiegabile timore reverenziale, accanirsi contro fatto sta che il ritorno di Mario Monti alla presidenza della Bocconi non ha raccolto tutti i commenti che avrebbe meritato, e dell appropriato tenore.";
        String portugueseText = "Esta documentación fue elaborada a partir de la documentación del proyecto FreeLing.";
        String spanishText = "Manuel Sánchez, alemán generales artesano de Artifex, zamorano contaba poco antes de recibir el galardón ayer noche, cómo se engendró el tipo.";
        String swedishText = "Det är mycket besvärligt väglag, vi uppmanar trafikanter att köra försiktigt.";
        String welshText = "Bu'r cynllun tocynnau bws am ddim yn llwyddiant ysgubol—mae wedi trawsnewid bywydau miloedd o bobl hŷn yng Nghasnewydd.";

        //Check size of input text.
        String[] words = italianText.split(" ");
        if (words.length > maxTextSize) {
            System.out.println("Text size is too big");
            System.exit(0);
        }

        //Pass the input text to semantic tagger of corresponding langauge.
        String taggedText = "";
        //taggedText = semanticTagger.tagChiText(chineseText); //Chinese
        //taggedText = semanticTagger.tagDutText(dutchText); //Dutch
        //taggedText = semanticTagger.tagEngText(englishText); //English
        //taggedText = semanticTagger.tagFrenText(frenchText); //French
        //taggedText = semanticTagger.tagItaText(italianText); //Italian
        //taggedText = semanticTagger.tagPortText(portugueseText); //Portuguese
        //taggedText = semanticTagger.tagSpanText(spanishText); //Spanish - version using on TreeTagger
        //taggedText = semanticTagger.tagSpanTextGrampal(spanishText); //Spanish - version using Grampal POS atgger
        //taggedText = semanticTagger.tagSwedText(swedishText); //Swedish
        taggedText = welshTagger.semTagWnlt(welshText); //Welsh

        System.out.println(taggedText);

        //Do something interesting as you like with the tagged text, including texts of different langauges.
    }

}

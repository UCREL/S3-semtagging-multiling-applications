
import ac.uk.lancs.ucrel.semtaggers.web.clients.SemanticTaggerClient;
import semtagger.welsh.webservice.client.WelshTaggerClient;

/**
 * This is a sample program for semantically tagging texts stored in files by
 * accessing USAS semantic tagger web service resided in Lancaster University.
 * This program is to be compiled together with a web service client library
 * files contained in the folder "./lib/" in the class path.
 *
 * @author Scott Piao (s.piao@lancaster.ac.uk). Last updated 21 June 2917.
 */
public class TagTextsInFile {

    public static void main(String[] args) {

        //Initiate taggers
        SemanticTaggerClient semanticTagger = new SemanticTaggerClient();
        WelshTaggerClient welshTagger = new WelshTaggerClient();

        //Limit the size of input text within 10000 words/tokens.
        int maxTextSize = 10000;

        //Open File
        //instantiate a class named OpenSaveFile used to open and save file.
        OpenSaveFile fileOpenSave = new OpenSaveFile();
        String encodingName = "UTF8";

        //Extract text from a file
        String text = fileOpenSave.getStringFromFile("files-4-test/english-sample-2.txt", encodingName);

        //If the file is too big, stop program.
        String[] words = text.split(" ");
        if (words.length > maxTextSize) {
            System.out.println("Text size is too big");
            System.exit(0);
        }

        //Tag text by calling the semantic tagger
        String taggedText = semanticTagger.tagEngText(text);

        System.out.println(taggedText);

        //Save the tagged text into a file
        String outFileName = "files-4-test/english-sample-2-tagged.txt";
        fileOpenSave.saveTextToFile(taggedText, outFileName, encodingName);

    }

}
